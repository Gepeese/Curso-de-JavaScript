console.log(typeof Object)

class Produto{}
console.log(typeof Produto)

//Exercicio
function mostraCarros(marca,modelo){
    console.log('O modelo '+modelo+' Pertence a '+marca)   
}

mostraCarros('Ferrari','F40')
