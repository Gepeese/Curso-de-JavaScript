console.log("Sentença de código")

{
    {
        console.log("hello world")
        console.log("olá") //Padrão do curso
    }

}