var a = 3 //Nomes são muito importantes
let b = 2 

var a = 30
 b = 20
 console.log(a,b)

const c = 5 //CONST: Não pode ser alterado depois
// c = 40
console.log(c)