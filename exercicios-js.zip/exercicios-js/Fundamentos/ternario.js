const resultado = nota => nota>=7 ? 'Aprovado' : 'Reprovado'

console.log(resultado(6.9))
console.log(resultado(8.5))
