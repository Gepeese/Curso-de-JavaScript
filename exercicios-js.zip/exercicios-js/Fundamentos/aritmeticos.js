const [a , b , c , d] = [ 3, 4, 5, 6]

const soma = a + b + c + d 
const subtracao = a - c
const multiplicacao = b * d
const divisao = c / d
const modulo = c % 2
console.log(soma, subtracao, multiplicacao, divisao, modulo)