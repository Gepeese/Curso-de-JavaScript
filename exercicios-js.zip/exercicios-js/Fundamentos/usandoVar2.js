var numero = 1
{
    var numero = 2
    console.log(numero)
}

console.log(numero)