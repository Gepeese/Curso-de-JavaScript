console.log('a = ',a)
var a = 2
console.log('a = ',a)

// Ele joga as variáveis para cima,
// Mesmo declarando depois.
// Nunca faça isso, serve apenas para curiosidade.


console.log('b = ', b)
let b = 3
console.log('b = ', b)
/*
    Com o let o efeito é diferente,
    não funcionará.

*/