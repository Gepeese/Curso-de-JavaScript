const [a] = [10]
console.log(a)

const[n1,n2,n3,n4,n5] = [10,7,9,0,11]
console.log(n1,n2,n3,n4,n5)