//Comentário de uma linha
console.log('Linha1')

/*

Comentário de 
Múltiplas 
Linhas

*/

console.log('Linha2') //Mostra na tela

/*
* Comentário de 
* Múltiplas 
* Linhas
*/